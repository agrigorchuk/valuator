//
//  xmlfilemodel.cpp
//  valuator
//
//  Created by Oleksandr Hryhorchuk on 9/23/14.
//  Copyright (c) 2014 Oleksandr Hryhorchuk. All rights reserved.
//
#include <iostream>

#include <libxml/list.h>
#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>

#include "xmlfilemodel.h"

void XMLFileModel::getElementNames(xmlNodePtr aNode)
{
//    std::vector<std::string> localResult;
//    xmlNodePtr currNode = NULL;
//    
//    for (currNode = aNode; currNode; currNode = currNode->next) {
//        if (currNode->type == XML_ELEMENT_NODE) {
//            
//            localResult.push_back(std::string((char *)currNode->name));
//            
//        }
//
//    }
    xmlNode *cur_node = NULL;
    
    for (cur_node = aNode; cur_node; cur_node = cur_node->next) {
        printf("node type: Element, name: %s\n", cur_node->name);
//        xmlNodeListGetString(doc, cur->xmlChildrenNode, 1);
//        if (cur_node->type == XML_ELEMENT_NODE) {
//            printf("node type: Element, name: %s\n", cur_node->name);
//            printf("node type: Element, name: %s\n", cur_node->content);
        
//        } else if (cur_node->type == XML_ELEMENT_CONTENT_ELEMENT ) {
//            printf("node type: Element, name: %s\n", cur_node->content);
//        }
        
        getElementNames(cur_node->children);
    }
}
bool XMLFileModel::openXMLFile( const std::string& aFileName )
{
    if (aFileName.empty())
    {
        // File name can't be empty!
        return false;
    }
    
    m_xmlDoc = xmlParseFile(aFileName.c_str());
    if (!m_xmlDoc)
    {
        std::cout << "Error opening, parsing XML file with name " << aFileName << std::endl;
        return false;
    }
    
    m_xmlRootNode = xmlDocGetRootElement(m_xmlDoc);
    
    if (!m_xmlRootNode) {
        std::cout << "Error getting root node from XML file named " << aFileName << std::endl;
        return false;
    }
    
    return true;
}

bool XMLFileModel::evaluateRootnode()
{
    if (!m_xmlDoc || !m_xmlRootNode)
    {
        std::cout << "Error! Doc and root node can't be null" << std::endl;
        return false;
    }
//    
//    while (m_xmlRootNode) {
//        
//        std::cout << m_xmlRootNode->name << std::endl;
////        xmlChar *prop = xmlNodeListGetString(m_xmlDoc, m_xmlRootNode->content, 0);
//        std::cout << m_xmlRootNode->content << std::endl;
//        m_xmlRootNode = m_xmlRootNode->next;
//    }
//
    getElementNames(m_xmlRootNode);
    return true;
}