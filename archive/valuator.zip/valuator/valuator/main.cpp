//
//  main.cpp
//  valuator
//
//  Created by Oleksandr Hryhorchuk on 9/23/14.
//  Copyright (c) 2014 Oleksandr Hryhorchuk. All rights reserved.
//

#include <iostream>
#include "xmlfilemodel.h"
#include "expressions.h"
#include <boost/container/vector.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/foreach.hpp>

#define BOOST_SPIRIT_USE_PHOENIX_V3
#include <boost/fusion/adapted/std_pair.hpp>
#include <boost/spirit/include/qi.hpp>
#include <boost/spirit/include/phoenix.hpp>

static const std::string k_additionExprName = "addition";
static const std::string k_multiplicationExprName = "multiplication";
static const std::string k_subtractionExprName = "subtraction";
static const std::string k_divisionExprName = "division";

int main(int argc, const char * argv[])
{
    using boost::property_tree::ptree;
    ptree pt;
    ptree resultTree;
    read_xml("/Users/g_alik/valuator.xml", pt);
    
    const ptree &expressions = pt.get_child("expressions");
//    auto z = expressions.get<int>("expressions.addition.id");
    
    
    if (expressions.empty())
        return -1;
//XML-код для парсинга std::string xmlCode = "<Data name="Position" x="5" y="5"/>";  //... парсим XML  //Получаем значения std::string name = propertyTree.get<std::string>("Data.<xmlattr>.name");
//    int x = expressions.get<int>("id");
//    int y = expressions.get<int>("id");
//    edge.get_child("<xmlattr>"
    
    BOOST_FOREACH(const ptree::value_type &currExpr, expressions){
        
        std::string readExprType = currExpr.first;
        
        std::cout << "currExpr = " << readExprType << std::endl;
        std::cout << "currExpr2 = " << currExpr.second.data() << std::endl;
        int nodeResult = 0;
        
        if (readExprType == k_additionExprName) {
            AbstractExpression *addExpr = new additionExpression();
            BOOST_FOREACH(const ptree::value_type & additionNodeEl, currExpr.second){
                std::string val = additionNodeEl.second.data();
                ((additionExpression*)addExpr)->addVal( atoi(val.c_str()) );
            }
            nodeResult = addExpr->evalExpr();
            std::cout << "addition result = " << nodeResult << std::endl;
            delete addExpr;
        } else if (readExprType == k_multiplicationExprName) {
            AbstractExpression *multExpr = new multiplicationExpression();
            BOOST_FOREACH(const ptree::value_type &multNodeEl, currExpr.second) {
                std::string val = multNodeEl.second.data();
                if (!val.empty())
                    ((multiplicationExpression*)multExpr)->addVal( atoi(val.c_str()) );
            }
            nodeResult = multExpr->evalExpr();
            std::cout << "multiplication node result = " << nodeResult << std::endl;
            delete multExpr;
        } else if (readExprType == k_subtractionExprName) {
            AbstractExpression *substrExpr = new substractionExpression();
            BOOST_FOREACH(const ptree::value_type &substNodeEl, currExpr.second) {
                std::string elTypeName = substNodeEl.first;
                std::string val = substNodeEl.second.data();
                if (elTypeName == "minuend") {
                    ((substractionExpression*)substrExpr)->setMinuend( atoi(val.c_str()) );
                } else if (elTypeName == "subtrahend") {
                    ((substractionExpression*)substrExpr)->setSubtrahend( atoi(val.c_str()) );
                }
            }
            nodeResult = substrExpr->evalExpr();
            std::cout << "subtraction node result = " << nodeResult << std::endl;
            delete substrExpr;
        } else if (readExprType == k_divisionExprName) {
            AbstractExpression *divExpr = new divisionExpression();
            BOOST_FOREACH(const ptree::value_type &divNodeEl, currExpr.second) {
                std::string elTypeName = divNodeEl.first;
                std::string val = divNodeEl.second.data();
                if ( elTypeName == "dividend" ) {
                    ((divisionExpression*)divExpr)->setDividend( atoi(val.c_str()) );
                } else if ( elTypeName == "divisor" ) {
                    ((divisionExpression*)divExpr)->setDivisor( atoi(val.c_str()) );
                }
            }
            nodeResult = divExpr->evalExpr();
            std::cout << "dividend node result = " << divExpr->evalExpr() << std::endl;
            delete divExpr;
        }
        resultTree.put(std::string("expressions.")+readExprType, nodeResult );
    }
    write_xml( "/Users/g_alik/valuator_result.xml", resultTree );
//    resultTree.
    return 0;
}

