//
//  xmlfilemodel.h
//  valuator
//
//  Created by Oleksandr Hryhorchuk on 9/23/14.
//  Copyright (c) 2014 Oleksandr Hryhorchuk. All rights reserved.
//

#ifndef __valuator__xmlfilemodel__
#define __valuator__xmlfilemodel__
#include <vector>

#include <libxml/parser.h>

    // Single tone which Models work with file

    class XMLFileModel
    {
    public:
        XMLFileModel() : m_xmlDoc(NULL), m_xmlRootNode(NULL)
        {}
        
        ~XMLFileModel()
        {
            xmlFreeDoc(m_xmlDoc);
        }
        
        // Opens XML file and reads ROOT node to m_xmlRootNode
        bool openXMLFile( const std::string& aFileName );
        bool evaluateRootnode();
        
    protected:
        void getElementNames(xmlNodePtr aNode);
        
    protected:
        xmlDocPtr m_xmlDoc;
        xmlNodePtr m_xmlRootNode;
    };


#endif /* defined(__valuator__xmlfilemodel__) */
